import type { IconSvgProps } from './Types';

import React from 'react';

export const IconSidebar: React.FC<IconSvgProps> = ({
    size = 32,
    width,
    height,
    children,
    ...props
}) => (
    <svg
        fill="none"
        height={size || height}
        viewBox="0 0 32 32"
        width={size || width}
        {...props}
    >
        {children}
    </svg>
);
